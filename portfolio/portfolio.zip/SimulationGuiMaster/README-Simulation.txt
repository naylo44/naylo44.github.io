PROJET SIMULATION 

Par Thomas Drolet, Guillaume Leblanc, Dominic Pichette, Era Sinbandith

1) Description

- Loups: 	"Sprite" de loup anim�
- Lapins: 	"Sprite" de lapin anim�
- Ratons :	"Sprite" de raton anim�
- Panda Roux :  "Sprite" de panda roux anim�
- Ours:		"Sprite" d'ours anim�
- Caribous:	"Sprite" de caribou
- Laitues:	"Sprite" de laitue anim�
- Cours d'eau:	"Sprite" d'eau anim�
- Collines:	Grands cercles verts
- Ravins:	Ovales bruns

2) Ce qui fonctionne
- Cr�ation des 7 organismes
- Gestion d'�nergie de ces 7 types d'objets
- Les animaux qui trouvent une cible soit pour trouver l'amour, pour se nourrir ou pour fuir un pr�dateur.
- Les d�placements pour fuir un pr�dateur ou pour aller vers une cible ou si aucune cible ils trouvent une cible au hasard.
- Les animaux qui mangent leur cible, leur redonne un certain % de l'�nergie de leur cible
- Les loups qui sprintent quand ils voient une cible � manger ainsi que la perte d'�nergie qui va avec.
- Cr�ation de cours d'eau
- Cr�ation de montagnes et de ravins
- Gestion du ralentissement des animaux dans les montagnes
- Gestion du "Spawn" des esp�ces pour ne pas qu'ils spawnent dans un cours d'eau/une montagne/un ravin
- Gestion du "souffle" de diff�rents animaux et leur noyade
- Faire pousser plus de laitue pr�s des cours d'eau
- Moment de la journ�e nuit/jour
- Faire pause/resumer et avancer temps par temps
- Sauvegarder les configurations (avec le nombre de chaque types d'animaux et le bon seed)
- Loader des configurations (avec le nombre de chaque types d'animaux et le bon seed)
- Animaux qui ralentissent quand ils montent la coline
- Le systeme d'energie, quand les animaux mangent �a augmente et leur activit� leur en font perdre
- Le syst�me de fatigue, ils doivent dormir ou en perde plus quand ils courent.
- Les animaux trouvent l�amour et la reproduction est plus "naturelle" (le b�b� spawn a c�t� des parents)
- Les clicks sur les objets pour faire appara�tre les informations.
- Diff�rentes saisons et les modifications de l'environnement et des animaux qui est associ� a ces saisons
(laitue ne survit pas en hiver)
- Des mondes plus gros que le canvas visible (Canvas scrollable, donc 5000x5000 no problem!)

3) Ce qui ne fonctionne pas
- Rien, since we're awesome...

- Non, s�rieusement, nous avons d� abandonner notre projet de faire des liens de familles
(les enfants ne se reproduiraient pas avec leur famille imm�diate).
